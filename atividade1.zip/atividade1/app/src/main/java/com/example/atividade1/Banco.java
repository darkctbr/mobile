package com.example.atividade1;

import android.content.ContentValues;
import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.database.Cursor;

public class Banco extends SQLiteOpenHelper {
    private static final String DATABASE_NAME = "meubanco.db";
    private static final int DATABASE_VERSION = 1;

    private static final String TABLE_NAME = "Filme";
    private static final String COLUMN_ID = "Id";
    private static final String COLUMN_TITULO = "Titulos";
    private static final String COLUMN_DIRETOR = "Diretor";
    private static final String COLUMN_ANO = "Ano";
    private static final String COLUMN_GENERO = "Gênero";
    private static final String COLUMN_VISTO = "visto";

    private static final String COLUMN_NOTA = "NOTA";

    public Banco(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);

    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        String CREATE_TABLE = "CREATE TABLE " + TABLE_NAME + " ("
                + COLUMN_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, "
                + COLUMN_TITULO + " TEXT, "
                + COLUMN_DIRETOR + " TEXT, "
                + COLUMN_ANO + " INTEGER, "
                + COLUMN_GENERO + " TEXT, "
                + COLUMN_VISTO + " TEXT, "
                + COLUMN_NOTA + " REAL)";
        db.execSQL(CREATE_TABLE);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_NAME);
        onCreate(db);

    }

    public long inserirUsuario(String titulo, String diretor,
            String ano, String genero, String visto, String nota)
    {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COLUMN_TITULO, titulo);
        values.put(COLUMN_DIRETOR, diretor);
        values.put(COLUMN_ANO, ano);
        values.put(COLUMN_GENERO, genero);
        values.put(COLUMN_VISTO, visto);
        values.put(COLUMN_NOTA, nota);
    }
    public int atualizarTarefa(int id, String titulo, String diretor, String ano, String genero, String visto, String nota) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COLUMN_TITULO, titulo);
        values.put(COLUMN_DIRETOR, diretor);
        values.put(COLUMN_ANO, ano);
        values.put(COLUMN_GENERO, genero);
        values.put(COLUMN_VISTO, visto);
        values.put(COLUMN_NOTA, nota);

        // Atualiza o registro baseado no ID
        return db.update(TABLE_NAME, values, COLUMN_ID + "=?", new String[]{String.valueOf(id)});
    }


    public Cursor listarTarefas() {
        SQLiteDatabase db = this.getReadableDatabase();
        return db.rawQuery("SELECT * FROM " + TABLE_NAME, null);
    }

    public int atualizarTarefa(String titulo, String diretor, String ano, String genero, String visto, String nota) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COLUMN_TITULO, titulo);
        values.put(COLUMN_DIRETOR, diretor);
        values.put(COLUMN_ANO, ano);
        values.put(COLUMN_GENERO, genero);
        values.put(COLUMN_VISTO, visto);
        values.put(COLUMN_NOTA, nota);
        return db.update(TABLE_NAME, values, COLUMN_ID + "=?", new String[]{String.valueOf(titulo)});
    }

    public int excluirTarefa(int id) {
        SQLiteDatabase db = this.getWritableDatabase();
        return db.delete(TABLE_NAME, COLUMN_ID + "=?", new String[]{String.valueOf(id)});
    }





}
