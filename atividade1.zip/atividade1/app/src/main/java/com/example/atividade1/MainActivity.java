package com.example.atividade1;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.RatingBar;
import android.widget.Spinner;
import android.widget.ArrayAdapter;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    private EditText edtTitulo, edtDiretor, edtAno;
    private Spinner spinnerGenero;
    private CheckBox checkboxVisto;
    private RatingBar ratingBarNota;
    private Button btnSalvar;
    private Banco banco;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        edtTitulo = findViewById(R.id.edtTitulo);
        edtDiretor = findViewById(R.id.edtDiretor);
        edtAno = findViewById(R.id.edtAno);
        spinnerGenero = findViewById(R.id.spinnerGenero);
        checkboxVisto = findViewById(R.id.checkboxVisto);
        ratingBarNota = findViewById(R.id.ratingBarNota);
        btnSalvar = findViewById(R.id.btnSalvar);

        banco = new Banco(this);

        // Adicionar opções ao Spinner
        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(this, R.array.generos, android.R.layout.simple_spinner_item);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinnerGenero.setAdapter(adapter);

        btnSalvar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                salvarFilme();
            }
        });
    }

    private void salvarFilme() {
        String titulo = edtTitulo.getText().toString();
        String diretor = edtDiretor.getText().toString();
        String ano = edtAno.getText().toString();
        String genero = spinnerGenero.getSelectedItem().toString();
        String visto = checkboxVisto.isChecked() ? "Sim" : "Não";
        String nota = String.valueOf(ratingBarNota.getRating());

        // Inserir no banco de dados
        banco.atualizarTarefa(titulo, diretor, ano, genero, visto, nota);
    }
}String titulo = "Filme Exemplo";
String diretor = "Diretor Exemplo";
String ano = "2023";
String genero = "Comédia";
String visto = "Sim";
String nota = "4.0";

// Chama o método para inserir o filme
long id = banco.Usuario(titulo, diretor, ano, genero, visto, nota);

// Se o id for maior que -1, significa que a inserção foi bem-sucedida
if (id != -1) {
        // O filme foi inserido com sucesso
        Log.d("Banco", "Filme inserido com sucesso, ID: " + id);
} else {
        // Algo deu errado com a inserção
        Log.d("Banco", "Erro ao inserir filme");
}

